﻿namespace QLMamNon.Constant
{
    public static class ViewBangThuTienFieldName
    {
        public const string SXThangTruoc = "SXThangTruoc";
        public const string AnSangThangTruoc = "AnSangThangTruoc";
        public const string SoTienAnSangThangNay = "SoTienAnSangThangNay";
        public const string AnToiThangTruoc = "AnToiThangTruoc";
        public const string SoTienAnToiThangNay = "SoTienAnToiThangNay";
        public const string SoTienNangKhieu = "SoTienNangKhieu";
        public const string SoTienTruyThu = "SoTienTruyThu";
        public const string SoTienDieuHoa = "SoTienDieuHoa";
        public const string SoTienDoDung = "SoTienDoDung";
        public const string ThanhTien = "ThanhTien";
        public const string PhuPhi = "PhuPhi";
        public const string BanTru = "BanTru";
        public const string HocPhi = "HocPhi";
        public const string PhucVuBanTru = "PhucVuBanTru";
        public const string TienAnVaSua = "TienAnSua";
        public const string TienSua = "TienSua";
        public const string SoTienAnSangConLai = "SoTienAnSangConLai";
        public const string SoTienAnToiConLai = "SoTienAnToiConLai";
        public const string TienAnSua = "TienAnSua";
        public const string KhoanThuChinh = "KhoanThuChinh";
        public const string SoTienNopLan1 = "SoTienNopLan1";
        public const string SoTienNopLan2 = "SoTienNopLan2";
        public const string TienAn = "TienAn";
        public const string HoTen = "HoTen";
        public const string NgayNopLan1 = "NgayNopLan1";
        public const string NgayNopLan2 = "NgayNopLan2";

    }
}
